package com.kd.ronakayurvedic;

import android.content.Context;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

public class DatabaseOpenHelper extends SQLiteAssetHelper {
    private static final String DB_NM = "RA_APP_DB.db";
    private static final int DB_VERSION = 1;

    public DatabaseOpenHelper(Context ctx){
        super(ctx, DB_NM, null, DB_VERSION);
    }
}
