package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;

public class Sell extends AppCompatActivity {

    Context ctx;
    DBManager dbM;
    Button back, profile, add_new, save;
    EditText txt_date, txt_bill, txt_c_nm, txt_c_addr, txt_qty, txt_mrp, txt_discount, txt_total;
    AutoCompleteTextView txt_cmp_nm, txt_prod, txt_batch;
    TextView total, discount, final_total;
    TableLayout data_tbl;
    TableRow tr;
    String[] sell_header;
    ArrayList<ArrayList<String>> sell_data;
    ArrayAdapter<String> cmp_adp, prod_adp, batch_adp;
    float tot, disc;
    int f_ttl, change_index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sell);

        Toolbar toolbar = findViewById(R.id.add_toolbar);
        setSupportActionBar(toolbar);

        ctx = this;
        dbM = DBManager.getInstance(ctx);

        back = findViewById(R.id.back);
        profile = findViewById(R.id.btn_profile);
        add_new = findViewById(R.id.btn_add_to_current);
        save = findViewById(R.id.btn_save_purchase);

// EditBox initialization
        txt_bill = findViewById(R.id.txt_sell_bill_no);
        txt_date = findViewById(R.id.txt_sell_date);
        txt_c_nm = findViewById(R.id.txt_sell_customer_nm);
        txt_c_addr = findViewById(R.id.txt_sell_customer_addr);
        txt_mrp = findViewById(R.id.txt_sell_mrp);
        txt_qty = findViewById(R.id.txt_sell_quantity);
        txt_discount = findViewById(R.id.txt_sell_discount);
        txt_total = findViewById(R.id.txt_sell_total);
// Autocomplete
        txt_cmp_nm = findViewById(R.id.txt_sell_cmp);
        txt_prod = findViewById(R.id.txt_sell_product);
        txt_batch = findViewById(R.id.txt_sell_batch_no);
// TextView
        total = findViewById(R.id.sell_ttl);
        discount = findViewById(R.id.sell_discount);
        final_total = findViewById(R.id.sell_f_ttl);

        data_tbl = findViewById(R.id.sell_tbl);

        sell_data = new ArrayList<>();
        dbM.open();
        events();
    }

    private void events() {

//  Back button onclick event
        devs.btn_back(this, back);
        devs.setDatePicker(ctx, txt_date);

//  Button onclick listener
        profile.setOnClickListener(btn_listener);
        add_new.setOnClickListener(btn_listener);
        save.setOnClickListener(btn_listener);

//  TextChange listener
        txt_discount.addTextChangedListener(txt_change);
        txt_mrp.addTextChangedListener(txt_change);
        txt_qty.addTextChangedListener(txt_change);

//  Set Adapters to EditText
        cmp_adp = new ArrayAdapter<String>(ctx, R.layout.support_simple_spinner_dropdown_item, dbM.getCompanyList());
        cmp_adp.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        txt_cmp_nm.setAdapter(cmp_adp);
        txt_cmp_nm.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String cmp = String.valueOf(parent.getItemAtPosition(position));
                setAdapterToProduct(cmp);
            }
        });

    }

//  set ArrayAdapters on correspondence selections
    private void setAdapterToProduct(String cmpnm){
        prod_adp = new ArrayAdapter<>(ctx, R.layout.support_simple_spinner_dropdown_item, dbM.getProductList(false, cmpnm));
        prod_adp.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        txt_prod.setAdapter(prod_adp);
        txt_prod.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String prod = String.valueOf(parent.getItemAtPosition(position));
                setAdapterToBatch(prod);
            }
        });
    }

    private void setAdapterToBatch(String pnm){
        ArrayList<String> batch_arr = dbM.getBatchNo(pnm);
        batch_adp = new ArrayAdapter<>(ctx, R.layout.support_simple_spinner_dropdown_item, batch_arr);
        batch_adp.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        txt_batch.setAdapter(batch_adp);
        if (batch_arr.size() == 1) {
            devs.setData(txt_batch, batch_arr.get(0));
            if (devs.chkNull(txt_cmp_nm, txt_prod, txt_batch)) {
                txt_mrp.setText(dbM.getMRP(new String[]{devs.getData(txt_cmp_nm), devs.getData(txt_prod), devs.getData(txt_batch)}));
            }
        }
        txt_batch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            if (devs.chkNull(txt_cmp_nm, txt_prod, txt_batch)) {
                txt_mrp.setText(dbM.getMRP(new String[]{devs.getData(txt_cmp_nm), devs.getData(txt_prod), devs.getData(txt_batch)}));
            }
            }
        });
    }
//  end of ArrayAdapters

    private void addHeader(){
        try {
            View v = data_tbl.getChildAt(0);
            if (v == null) {
                sell_header = new String[]{"No.", "Bill no.", "Date", "Company", "Product", "Bench no.", "MRP", "Qty", "Discount", "Total", "Edit", "Delete"};
                devs.addHeaderFields(ctx, data_tbl, sell_header);
            }
        } catch (Exception ex) {
            devs.Toasty(ctx, ex.getMessage());
        }
    }

//  Discount, Total and Final Total Operations
    private void updateTotal(){
        total.setText(String.valueOf(tot));
        discount.setText(String.valueOf(disc));
        final_total.setText(String.valueOf(f_ttl));
    }
    private float getTotal(){
        String mrp = devs.getData(txt_mrp);
        String qty = devs.getData(txt_qty);
        float TOTAL = 0;
        if (!mrp.isEmpty() && !qty.isEmpty()) {
            float MRP = Float.valueOf(mrp);
            float QTY = Float.valueOf(qty);
            TOTAL = MRP * QTY;
        }
        return TOTAL;
    }
    private float getDisc(){
        String disc = devs.getData(txt_discount);
        disc = disc.equals("") ? "0" : disc;
        float DISC = Float.valueOf(disc.replaceAll("[^0-9]", ""));
        return ((getTotal() * DISC) / 100);
    }
    private int getQTY(){
        try {
            if (devs.chkNull(txt_qty)) {
                return Integer.valueOf(devs.getData(txt_qty));
            }
        } catch (Exception ex) {
            devs.Toasty(ctx, ex.getMessage());
        }
        return 0;
    }

//  Listener class for all Views
    private View.OnClickListener btn_listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(v instanceof Button){
                if (v == add_new) {
                    boolean flag = devs.chkNull(txt_bill, txt_date, txt_c_nm, txt_c_addr, txt_cmp_nm, txt_prod, txt_batch, txt_mrp, txt_qty, txt_discount, txt_total);
                    if (flag) {
                        flag = !devs.getData(txt_qty).equals("0") &&
                                dbM.getCompanyList().contains(devs.getData(txt_cmp_nm)) &&
                                dbM.getProductList(false, devs.getData(txt_cmp_nm)).contains(devs.getData(txt_prod)) &&
                                dbM.getBatchNo(devs.getData(txt_prod)).contains(devs.getData(txt_batch));
                    }
                    if (!add_new.getTag().equals("Edit") && flag) {
                        ArrayList<String> datas = devs.append(txt_bill, txt_date, txt_cmp_nm, txt_prod, txt_batch, txt_mrp, txt_qty, txt_discount, txt_total);
                        int i = sell_data.size();
                        sell_data.add(i, datas);

                        addHeader();
                        tr = devs.fillRow(ctx, datas, i, devs.getFieldsArray(new int[]{7}));
                        tr.addView(devs.getImage(ctx, btn_listener, "edit_icon"));
                        tr.addView(devs.getImage(ctx, btn_listener, "delete_icon"));
                        data_tbl.addView(tr);

                        tot += getTotal();
                        disc += getDisc();
                        f_ttl = Math.round(tot - disc);
                        updateTotal();

                        devs.empty(txt_cmp_nm, txt_prod, txt_batch, txt_mrp, txt_qty, txt_discount, txt_total);

                    } else if (add_new.getTag().equals("Edit") && flag) {

                        ArrayList<String> one_data = sell_data.get(change_index);
                        float mrp = Float.valueOf(one_data.get(5));
                        float qty = Float.valueOf(one_data.get(6));
                        float dis = Float.valueOf(one_data.get(7));
                        tot -= mrp * qty;
                        disc -= (mrp * qty * dis) / 100;
                        f_ttl = Math.round(tot - disc);

                        ArrayList<String> datas = devs.append(txt_bill, txt_date, txt_cmp_nm, txt_prod, txt_batch, txt_mrp, txt_qty, txt_discount, txt_total);
                        sell_data.add(change_index, datas);

                        tr = devs.fillRow(ctx, datas, change_index, devs.getFieldsArray(new int[]{7}));
                        tr.addView(devs.getImage(ctx, btn_listener, "edit_icon"));
                        tr.addView(devs.getImage(ctx, btn_listener, "delete_icon"));
                        data_tbl.removeView(data_tbl.getChildAt(change_index+1));
                        data_tbl.addView(tr, change_index+1);

                        tot += getTotal();
                        disc += getDisc();
                        f_ttl = Math.round(tot - disc);
                        updateTotal();

                        devs.empty(txt_cmp_nm, txt_prod, txt_batch, txt_mrp, txt_qty, txt_discount, txt_total);
                        add_new.setTag("Add");
                    } else {
                        devs.Toasty(ctx, "Fill all the datas properly");
                    }
                } else if (v == save) {
                    if (sell_data.size() != 0) {
                        for(ArrayList<String> one : sell_data){
                            one.add(9, devs.getData(txt_c_nm));
                            one.add(10, devs.getData(txt_c_addr));
                        }
                        if (dbM.do_sell(sell_data)) {
                            devs.getPDF(ctx, sell_data, f_ttl, devs.getData(txt_c_nm), devs.getData(txt_c_addr), devs.getData(txt_date), devs.getData(txt_bill));
                            data_tbl.removeAllViews();
                            tot = 0.0f; disc = 0.0f; f_ttl = 0;
                            updateTotal();
                            devs.Toasty(ctx, "Inserted successfully");
                            devs.empty(txt_bill, txt_c_nm, txt_c_addr, txt_date);
                        } else {
                            devs.Toasty(ctx, "Some problem occurs,\nNot inserted successfully");
                        }
                    } else {
                        devs.Toasty(ctx, "Please first insert the data");
                    }
                } else if(v == profile) {
                    devs.call_intent(ctx, getApplicationContext(), Profile.class);
                }
            } else if (v instanceof ImageView){
                if (v.getTag().equals("delete_icon")) {
                    TableRow data_row = (TableRow) v.getParent();
                    TextView tv = (TextView) data_row.getChildAt(0);

                    int index = Integer.valueOf(tv.getText().toString()) - 1;
                    ArrayList<String> one_data = sell_data.get(index);
                    float mrp = Float.valueOf(one_data.get(5));
                    float qty = Float.valueOf(one_data.get(6));
                    float dis = Float.valueOf(one_data.get(7));
                    tot -= mrp * qty;
                    disc -= (mrp * qty * dis) / 100;
                    f_ttl = Math.round(tot - disc);

                    updateTotal();
                    data_tbl.removeView(data_row);
                    sell_data.remove(index);
                } else if (v.getTag().equals("edit_icon")) {
                    TableRow data_row = (TableRow) v.getParent();
                    TextView tv = (TextView) data_row.getChildAt(0);
                    int index = Integer.valueOf(tv.getText().toString()) - 1;
                    ArrayList<String> one_data = sell_data.get(index);
                    devs.setData(txt_bill, one_data.get(0));
                    devs.setData(txt_date, one_data.get(1));
                    devs.setData(txt_cmp_nm, one_data.get(2));
                    devs.setData(txt_prod, one_data.get(3));
                    devs.setData(txt_batch, one_data.get(4));
                    devs.setData(txt_mrp, one_data.get(5));
                    devs.setData(txt_qty, one_data.get(6));
                    devs.setData(txt_discount, one_data.get(7));
                    devs.setData(txt_total, one_data.get(8));
                    txt_c_nm.setFocusable(false);
                    txt_c_addr.setFocusable(false);
                    add_new.setTag("Edit");
                    change_index = index;
                }
            }
        }
    };

//  Listener class for EditTextBoxes
    TextWatcher txt_change = new TextWatcher() {
        @Override
        public void afterTextChanged(Editable s) {
            try {
                if (getQTY() != 0 && devs.chkNull(txt_cmp_nm, txt_prod, txt_batch)) {
                    int realQTY = dbM.getQTY(new String[]{devs.getData(txt_cmp_nm), devs.getData(txt_prod), devs.getData(txt_batch)});
                    if (realQTY == 0) {
                        devs.Toasty(ctx, "No stock available of this product, can't entry");
                        txt_qty.setText("0");
                    } else if (getQTY() > realQTY) {
                        txt_qty.setError("Maximum in stock is " + realQTY);
                        txt_qty.setText("");
                    }
                }
                float TOTAL = getTotal();
                float DISC = getDisc();
                if (TOTAL != 0) {
                    float AMOUNT = TOTAL - DISC;
                    txt_total.setText(String.valueOf(AMOUNT));
                }
            } catch (Exception ex) {
                devs.Toasty(ctx, "Please insert valid data,\n" + ex.getMessage());
            }
        }

        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
    };

}
