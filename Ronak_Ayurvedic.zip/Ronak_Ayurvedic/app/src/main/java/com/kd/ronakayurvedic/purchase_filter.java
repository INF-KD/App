package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class purchase_filter extends AppCompatActivity {

    Context ctx;
    DBManager dbM;
    Button back, view, clear;
    EditText from_date, to_date;
    TextView lbl_ttl, lbl_disc, lbl_gst, lbl_f_ttl;
    AutoCompleteTextView txt_purchaseProduct;
    TableLayout data_tbl, purchase_tbl;
    TableRow tr;
    String[] fields;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.purchase_filter);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ctx = this;
        dbM = DBManager.getInstance(ctx);

//  Button
        back = findViewById(R.id.back);
        clear = findViewById(R.id.btn_clear);
        view = findViewById(R.id.btn_view);
//  EditText
        from_date = findViewById(R.id.txt_pf_from_date);
        to_date = findViewById(R.id.txt_pf_to_date);
        txt_purchaseProduct = findViewById(R.id.txt_prod_nm);
//  TextView
        lbl_ttl = findViewById(R.id.p_ttl);
        lbl_disc = findViewById(R.id.p_disc);
        lbl_gst = findViewById(R.id.p_gst);
        lbl_f_ttl = findViewById(R.id.p_f_ttl);
//  TableLayout
        data_tbl = findViewById(R.id.purchase_f_tbl);
        purchase_tbl = findViewById(R.id.purchase_f_bill_tbl);

        dbM.open();
        events();
    }

    private void events() {

//  Back button onclick event
        devs.btn_back(this, back);
        devs.setDatePicker(ctx, from_date);
        devs.setDatePicker(ctx, to_date);

//  Add autocomplete hints to textbox
        ArrayAdapter<String> forAuto = new ArrayAdapter<String>(ctx, R.layout.support_simple_spinner_dropdown_item, dbM.getPurchaseProductList());
        forAuto.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        txt_purchaseProduct.setAdapter(forAuto);

//  Button event
        view.setOnClickListener(view_listener);
        clear.setOnClickListener(view_listener);

    }

    private void addHeaderList(){
        try {
            View v = data_tbl.getChildAt(0);
            if (v == null) {
                fields = new String[]{"No.", "Bill no.", "Date", "View"};
                devs.addHeaderFields(ctx, data_tbl, fields);
            }
        } catch (Exception ex){
            devs.Toasty(ctx, ex.getMessage());
        }
    }
    private void addPurchaseHeader(){
        try {
            View v = purchase_tbl.getChildAt(0);
            if (v == null) {
                fields = new String[]{"No.", "Bill no.", "Date", "Company", "Product", "Bench no.", "Net rate", "Qty", "MRP", "SGST%", "CGST%", "Discount", "Total"};
                devs.addHeaderFields(ctx, purchase_tbl, fields);
            }
        } catch (Exception ex){
            devs.Toasty(ctx, ex.getMessage());
        }
    }

    private View.OnClickListener view_listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
        if(v instanceof Button){
            if (v == view) {
                ArrayList<ArrayList<String>> datas = new ArrayList<>(0);
                try {
                    String prod = "", fromDate = "", toDate = "";
                    if (devs.chkNull(txt_purchaseProduct, from_date, to_date)) {
                        prod = devs.getData(txt_purchaseProduct);
                        Date dt1 = new SimpleDateFormat("yyyy-MM-dd").parse(devs.getData(from_date));
                        Date dt2 = new SimpleDateFormat("yyyy-MM-dd").parse(devs.getData(to_date));
                        if (dt1.before(dt2)) {
                            fromDate = devs.getData(from_date);
                            toDate = devs.getData(to_date);
                        } else {
                            fromDate = devs.getData(to_date);
                            toDate = devs.getData(from_date);
                        }
                        datas = dbM.getPurchaseList(prod, fromDate, toDate);
                    } else if (devs.chkNull(txt_purchaseProduct)) {
                        prod = devs.getData(txt_purchaseProduct);
                        datas = dbM.getPurchaseList(prod);
                    } else if (devs.chkNull(from_date, to_date)) {
                        Date dt1 = new SimpleDateFormat("yyyy-MM-dd").parse(devs.getData(from_date));
                        Date dt2 = new SimpleDateFormat("yyyy-MM-dd").parse(devs.getData(to_date));
                        if (dt1.before(dt2)) {
                            fromDate = devs.getData(from_date);
                            toDate = devs.getData(to_date);
                        } else {
                            fromDate = devs.getData(to_date);
                            toDate = devs.getData(from_date);
                        }
                        datas = dbM.getPurchaseList(fromDate, toDate);
                    } else {
                        datas = dbM.getPurchaseList();
                    }
                }catch (Exception ex){
                    devs.Toasty(ctx, "Some error occurs,\n"+ex.getMessage());
                }
                if(datas.size() != 0){
                    data_tbl.removeAllViews();
                    addHeaderList();
                    int i = 0;
                    for (ArrayList<String> data : datas){
                        tr = devs.fillRow(ctx, data, i, devs.getFieldsArray(new int[]{}));
                        tr.addView(devs.getImage(ctx, view_listener, "view_data"));
                        data_tbl.addView(tr);
                        i++;
                    }
                } else{
                    devs.Toasty(ctx, "No data founds, try different choices");
                }
            } else if (v == clear) {
                data_tbl.removeAllViews();
                purchase_tbl.removeAllViews();
                devs.empty(txt_purchaseProduct, from_date, to_date);
                devs.empty(lbl_ttl, lbl_disc, lbl_gst, lbl_f_ttl);
            }
        } else if (v instanceof ImageView) {
            try{
            if (v.getTag().equals("view_data")){
                float ttl = 0, gst = 0, disc = 0;
                int f_ttl = 0;
                TableRow tr = (TableRow) v.getParent();
                TextView billNo = (TextView) tr.getChildAt(1);
                ArrayList<ArrayList<String>> datas = dbM.getPurchase(billNo.getText().toString());
                if (datas.size() != 0){
                purchase_tbl.removeAllViews();
                addPurchaseHeader();
                int i = 0;
                for (ArrayList<String> data : datas) {
                    tr = devs.fillRow(ctx, data, i, devs.getFieldsArray(new int[]{8, 9, 10}));
                    purchase_tbl.addView(tr);
                    float total = Float.valueOf(data.get(5)) * Float.valueOf(data.get(6));
                    ttl += total;
                    disc += (total * Float.valueOf(data.get(10)))/100;
                    total -= (total * Float.valueOf(data.get(10)))/100;
                    gst += (total * (Float.valueOf(data.get(8)) + Float.valueOf(data.get(9))))/100;
                    i++;
                }
                f_ttl += Math.round((ttl - disc) + gst);
                lbl_ttl.setText("Total \t\t :: \t "+ ttl);
                lbl_disc.setText("Discount \t :: \t "+ disc);
                lbl_gst.setText("GST \t\t :: \t "+ gst);
                lbl_f_ttl.setText("Grand \t\t :: \t "+ f_ttl);
                } else {
                    devs.Toasty(ctx, "No data founds");
                }
            }
            } catch (Exception ex){
                devs.Toasty(ctx, "Not viewing, some problem occurs,\n"+ ex.getMessage());
            }
        }
        }
    };

}
