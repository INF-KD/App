package com.kd.ronakayurvedic;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;

public class DBManager {
    private DatabaseOpenHelper openHelper;
    private SQLiteDatabase db;
    private static DBManager instance;
    Context ctx;
    Cursor crs = null;

    private DBManager(Context ctx){
        this.openHelper = new DatabaseOpenHelper(ctx);
        this.ctx = ctx;
    }

    public static DBManager getInstance(Context ctx){
        if(instance == null){
            instance = new DBManager(ctx);
        }
        return instance;
    }

/**
 * All purchase operations
 */

        public boolean do_purchase(ArrayList<ArrayList<String>> datas){
            try{
                for(ArrayList<String> data : datas){
                    ContentValues cval = new ContentValues();
                    cval.put("bill_no", data.get(0));
                    cval.put("date", data.get(1));
                    cval.put("cmp", data.get(2));
                    cval.put("prod", data.get(3));
                    cval.put("batch_no", data.get(4));
                    cval.put("net_rate", Float.valueOf(data.get(5)));
                    cval.put("qty", Integer.valueOf(data.get(6)));
                    cval.put("mrp", Float.valueOf(data.get(7)));
                    cval.put("sgst", Float.valueOf(data.get(8)));
                    cval.put("cgst", Float.valueOf(data.get(9)));
                    cval.put("disc", Float.valueOf(data.get(10)));
                    cval.put("total", Float.valueOf(data.get(11)));
                    db.insert("PURCHASE", null, cval);
                }
            }catch (Exception ex){
                Log.d("Insert", ex.getMessage());
                return false;
            }
            return true;
        }

        public ArrayList<ArrayList<String>> getPurchase(String bill_no){
            ArrayList<ArrayList<String>> datas = new ArrayList<>();
            crs = db.rawQuery("SELECT * FROM PURCHASE WHERE bill_no = '" + bill_no + "' ", null);
            while (crs.moveToNext()){
                ArrayList<String> data = new ArrayList<>();
                data.add(0, crs.getString(1));
                data.add(1, crs.getString(2));
                data.add(2, crs.getString(3));
                data.add(3, crs.getString(4));
                data.add(4, crs.getString(5));
                data.add(5, String.valueOf(crs.getFloat(6)));
                data.add(6, String.valueOf(crs.getInt(7)));
                data.add(7, String.valueOf(crs.getFloat(8)));
                data.add(8, String.valueOf(crs.getFloat(9)));
                data.add(9, String.valueOf(crs.getFloat(10)));
                data.add(10, String.valueOf(crs.getFloat(11)));
                data.add(11, String.valueOf(crs.getFloat(12)));
                datas.add(data);
            }
            return datas;
        }

        public ArrayList<String> getPurchaseProductList(){
            ArrayList<String> list = new ArrayList<String>();
            if(db.isOpen()){
                crs = db.rawQuery("SELECT DISTINCT prod FROM PURCHASE ORDER BY prod", null);
                while (crs.moveToNext()){
                    list.add(crs.getString(0));
                }
            }
            return list;
        }

        public ArrayList<ArrayList<String>>  getPurchaseList(){
            ArrayList<ArrayList<String>> datas = new ArrayList<>();
            crs = db.rawQuery("SELECT bill_no, date FROM PURCHASE GROUP BY bill_no", null);
            while (crs.moveToNext()){
                ArrayList<String> data = new ArrayList<>();
                data.add(0, crs.getString(0));
                data.add(1, crs.getString(1));
                datas.add(data);
            }
            return datas;
        }
        public ArrayList<ArrayList<String>>  getPurchaseList(String prod) {
            ArrayList<ArrayList<String>> datas = new ArrayList<>();
            crs = db.rawQuery("SELECT bill_no, date FROM PURCHASE WHERE prod='" + prod + "' GROUP BY bill_no", null);
            while (crs.moveToNext()){
                ArrayList<String> data = new ArrayList<>();
                data.add(0, crs.getString(0));
                data.add(1, crs.getString(1));
                datas.add(data);
            }
            return datas;
        }
        public ArrayList<ArrayList<String>>  getPurchaseList(String from_date, String to_date){
            ArrayList<ArrayList<String>> datas = new ArrayList<>();
            crs = db.rawQuery("SELECT bill_no, date FROM PURCHASE WHERE date BETWEEN '"+ from_date +"' AND '"+ to_date +"' GROUP BY bill_no", null);
            while (crs.moveToNext()){
                ArrayList<String> data = new ArrayList<>();
                data.add(0, crs.getString(0));
                data.add(1, crs.getString(1));
                datas.add(data);
            }
            return datas;
        }
        public ArrayList<ArrayList<String>>  getPurchaseList(String prod, String from_date, String to_date){
            ArrayList<ArrayList<String>> datas = new ArrayList<>();
            crs = db.rawQuery("SELECT bill_no, date FROM PURCHASE WHERE date BETWEEN '"+ from_date +"' AND '"+ to_date +"' AND prod='" + prod + "' GROUP BY bill_no", null);
            while (crs.moveToNext()){
                ArrayList<String> data = new ArrayList<>();
                data.add(0, crs.getString(0));
                data.add(1, crs.getString(1));
                datas.add(data);
            }
            return datas;
        }
// SELECT (PURCHASE.qty - SELL.qty) AS 'Hola' FROM PURCHASE, SELL WHERE SELL.cmp= 'Amazon' AND PURCHASE.cmp = 'Amazon'
/**
 * All sell operations
 */
        public boolean do_sell(ArrayList<ArrayList<String>> datas){
            try{
                for(ArrayList<String> data : datas){
                    ContentValues cval = new ContentValues();
                    cval.put("bill_no", data.get(0));
                    cval.put("date", data.get(1));
                    cval.put("c_nm", data.get(9));
                    cval.put("c_addr", data.get(10));
                    cval.put("cmp", data.get(2));
                    cval.put("prod", data.get(3));
                    cval.put("batch_no", data.get(4));
                    cval.put("mrp", Float.valueOf(data.get(5)));
                    cval.put("qty", Integer.valueOf(data.get(6)));
                    cval.put("disc", Float.valueOf(data.get(7)));
                    cval.put("total", Float.valueOf(data.get(8)));

                    db.insert("SELL", null, cval);
                }
            }catch (Exception ex){
                Log.d("Insert", ex.getMessage());
                return false;
            }
            return true;
        }

/**
 *  All product operations
 *  product insert, delete
 *  get product details
 *  get product name list
 *  Related to PRODUCT table
 */

        public boolean ins_product(ArrayList<String> p_details){
            try {
                ContentValues cts = new ContentValues();
                cts.put("p_nm", p_details.get(0));
                cts.put("p_cmp_nm", p_details.get(1));
                db.insert("PRODUCT", null, cts);
            }catch (Exception ex){
                return false;
            }
            return true;
        }

        public boolean del_product(String index){
            try {
                int id = Integer.valueOf(index);
                db.execSQL("UPDATE PRODUCT SET p_stat='InTrash' WHERE p_id=" + id + "");
            }catch (Exception ex){
                return false;
            }
            return true;
        }

        public ArrayList<ArrayList<String>> getProducts(){
            ArrayList<ArrayList<String>> list = new ArrayList<ArrayList<String>>();
            crs = db.rawQuery("SELECT * FROM PRODUCT WHERE p_stat='InUse' ORDER BY p_nm", null);
            while (crs.moveToNext()){
                ArrayList<String> one = new ArrayList<String>();
                one.add(0, crs.getString(1));
                one.add(1, crs.getString(2));
                one.add(2, String.valueOf(crs.getInt(0)));
                list.add(one);
            }
            return list;
        }

        public ArrayList<String> getProductList(){
            ArrayList<String> list = new ArrayList<String>();
            crs = db.rawQuery("SELECT p_nm FROM PRODUCT WHERE p_stat='InUse' ORDER BY p_nm", null);
            while (crs.moveToNext()) {
                list.add(crs.getString(0));
            }
            return list;
        }
        public ArrayList<String> getProductList(boolean fromPROD, String cmp){
            ArrayList<String> list = new ArrayList<String>();
            if (fromPROD) {
                crs = db.rawQuery("SELECT p_nm FROM PRODUCT WHERE p_cmp_nm ='" + cmp + "' ORDER BY p_nm", null);
            } else {
                crs = db.rawQuery("SELECT DISTINCT prod FROM PURCHASE WHERE cmp='" + cmp + "' ORDER BY prod", null);
            }
            while (crs.moveToNext()) {
                list.add(crs.getString(0));
            }
            return list;
        }

/**
 *  All company operations
 *  Related to COMPANY table
 *  insert, delete company
 *  get company details and company name list
 */

        public boolean ins_company(ArrayList<String> c_data){
            try {
                ContentValues data = new ContentValues();
                data.put("c_nm", c_data.get(0));
                data.put("c_owner", c_data.get(1));
                data.put("c_loc", c_data.get(2));
                data.put("c_cont", c_data.get(3));
                db.insert("COMPANY", null, data);
            }catch (Exception ex){
                return false;
            }
            return true;
        }

        public boolean del_company(String index){
            try {
                int id = Integer.valueOf(index);
                db.execSQL("UPDATE COMPANY SET c_stat='InTrash' WHERE c_id=" + id + "");
            }catch (Exception ex){
                return false;
            }
            return true;
        }

        public ArrayList<ArrayList<String>> getCompanies(){
            ArrayList<ArrayList<String>> list = new ArrayList<ArrayList<String>>();
            try {
                crs = db.rawQuery("SELECT DISTINCT * FROM COMPANY WHERE c_stat='InUse' ORDER BY c_nm", null);
                while (crs.moveToNext()) {
                    ArrayList<String> one = new ArrayList<String>();
                    one.add(0, crs.getString(1));
                    one.add(1, crs.getString(2));
                    one.add(2, crs.getString(3));
                    one.add(3, crs.getString(4));
                    one.add(4, crs.getString(0));
                    list.add(one);
                }
            }catch (Exception ex){

            }finally {
                return list;
            }
        }

        public ArrayList<String> getCompanyList(){
            ArrayList<String> list = new ArrayList<String>();
            crs = db.rawQuery("SELECT DISTINCT cmp FROM PURCHASE ORDER BY cmp", null);
            while (crs.moveToNext()) {
                list.add(crs.getString(0));
            }
            return list;
        }
        public ArrayList<String> getCompanyList(boolean fromCMP){
            ArrayList<String> list = new ArrayList<String>();
            list.add("Select Company");
            crs = db.rawQuery("SELECT c_nm FROM COMPANY WHERE c_stat='InUse' ORDER BY c_nm", null);
            while (crs.moveToNext()) {
                list.add(crs.getString(0));
            }
            return list;
        }

    public ArrayList<String> getSellProductList(){
        ArrayList<String> list = new ArrayList<String>();
        return list;
    }

    public ArrayList<String> getCustomerList(){
        ArrayList<String> list = new ArrayList<String>();
        return list;
    }

    public ArrayList<String> getBatchNo(String pnm){
        ArrayList<String> list = new ArrayList<String>();
        crs = db.rawQuery("SELECT DISTINCT batch_no FROM PURCHASE WHERE prod='"+ pnm +"' ORDER BY batch_no", null);
        while (crs.moveToNext()) {
            list.add(crs.getString(0));
        }
        return list;
    }

//  C_P_B = Company, Product, Batch No
    public int getQTY(String[] C_P_B){
        crs = db.rawQuery("SELECT qty FROM PURCHASE WHERE cmp = ? AND prod = ? AND batch_no = ?", C_P_B);
        crs.moveToFirst();
        return crs.getInt(0);
    }

    public String getMRP(String[] C_P_B){
        crs = db.rawQuery("SELECT mrp FROM PURCHASE WHERE cmp = ? AND prod = ? AND batch_no = ?", C_P_B);
        crs.moveToFirst();
        return String.valueOf(crs.getFloat(0));
    }

    public void open(){
        this.db = openHelper.getWritableDatabase();
    }

    public void close(){
        if(db != null){
            this.db.close();
        }
    }
}
