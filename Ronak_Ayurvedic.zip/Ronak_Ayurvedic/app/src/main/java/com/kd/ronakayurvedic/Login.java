package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Login extends AppCompatActivity {

    EditText user, pass;
    Context context;
    Button btn_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.login);
        context = this;

        user = findViewById(R.id.txt_user);
        pass = findViewById(R.id.txt_pass);
        btn_login = findViewById(R.id.btn_login);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String unm = user.getText().toString();
                String p = pass.getText().toString();
                if(unm.equals("Gautam") && p.equals("gg")){
                    Intent go_to_welcome = new Intent(getApplicationContext(), Welcome.class);
                    startActivity(go_to_welcome);
                }
            }
        });

    }

}
