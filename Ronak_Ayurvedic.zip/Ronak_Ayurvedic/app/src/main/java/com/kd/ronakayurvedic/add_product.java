package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

import java.util.ArrayList;

public class add_product extends AppCompatActivity {

    Button profile, back, save, cancel;
    DBManager dbM;
    EditText prod_nm;
    Context ctx;
    TableLayout prod_tbl;
    TableRow tr;
    ArrayAdapter<String> adt, cmp_adp;
    Spinner spin, cmp_nm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_product);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ctx = this;
        dbM = DBManager.getInstance(ctx);
        back = findViewById(R.id.back);
        profile = findViewById(R.id.btn_profile);
        prod_nm = findViewById(R.id.txt_product_nm);
        cmp_nm = findViewById(R.id.cmp_nm);
        prod_tbl = findViewById(R.id.prod_tbl);
        save = findViewById(R.id.btn_add_product);

        dbM.open();
        events();
        updateTable();
    }

    private void events() {

//  Back button onclick event
        devs.btn_back(ctx, back);

// go to profile event
        profile.setOnClickListener(clk_listener);
        save.setOnClickListener(clk_listener);

        cmp_adp = new ArrayAdapter<String>(ctx, R.layout.custom_spin_view, dbM.getCompanyList(true));
        cmp_nm.setAdapter(cmp_adp);
        cmp_nm.setSelected(true);
    }

    private void updateTable(){
        prod_tbl.removeAllViews();
        ArrayList<ArrayList<String>> list = dbM.getProducts();

        for(ArrayList<String> one : list) {
            ArrayList<String> prod_details = new ArrayList<String>();
            prod_details.add(one.get(0));
            prod_details.add(one.get(1));

            adt = new ArrayAdapter<String>(ctx, R.layout.custom_spin_view, prod_details);
            adt.setDropDownViewResource(R.layout.custom_spin_view);

            spin = new Spinner(ctx, Spinner.MODE_DIALOG);
            spin.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1.7f));
            spin.setAdapter(adt);
            spin.setSelected(true);

            cancel = new Button(ctx);
            cancel.setBackgroundResource(R.drawable.delete);
            cancel.setTag(one.get(2));
            cancel.setOnClickListener(clk_listener);
            cancel.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 0.3f));

            tr = new TableRow(ctx);
            tr.setWeightSum(2);
            tr.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

            prod_tbl.addView(tr);
            tr.addView(spin, 0);
            tr.addView(cancel, 1);
        }
    }

    private View.OnClickListener clk_listener = new View.OnClickListener() {
        public void onClick(View v) {
            if(v instanceof Button) {
                if(v == save){
                    String prod = prod_nm.getText().toString();
                    String cmp = cmp_nm.getSelectedItem().toString();
                    if(!prod.equals("") && !cmp.equals("") && !cmp.equals("Select Company")) {
                        ArrayList<String> p_details = new ArrayList<String>();
                        p_details.add(prod);
                        p_details.add(cmp);
                        if(dbM.ins_product(p_details)) {
                            updateTable();
                            p_details.clear();
                            devs.Toasty(ctx, "Inserted!");
                            devs.empty(prod_nm);
                            cmp_nm.setSelection(0);
                        }else{
                            devs.Toasty(ctx, "Some problem occures,\nNot inserted successfully");
                        }
                    }else{
                        devs.Toasty(ctx, "Any field is blank,\nNot inserted successfully");
                    }
                }else if(v == profile){
                    devs.call_intent(ctx, getApplicationContext(), Profile.class);
                }else if(v.getTag() != null){
                    String index = v.getTag().toString();
                    if(dbM.del_product(index)) {
                        updateTable();
                    }else{
                        devs.Toasty(ctx, "Not deleted");
                    }
                }

            }
        }
    };
}

/*
prod_details = new ArrayList<String>();
                String prod = prod_nm.getText().toString();
                String cmp = cmp_nm.getSelectedItem().toString();
                prod_details.add(prod);
                prod_details.add(cmp);

                adt =new ArrayAdapter<String>(ctx, R.layout.custom_spin_view, prod_details);
                adt.setDropDownViewResource(R.layout.custom_spin_view);
                adt.notifyDataSetChanged();

                spin = new Spinner(ctx, Spinner.MODE_DIALOG);
                spin.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1.7f));
                spin.setAdapter(adt);
                spin.setSelected(true);

                cancel = new Button(ctx);
                cancel.setBackgroundResource(R.drawable.del_icon);
                cancel.setTag(prod);
                cancel.setOnClickListener(clk_listener);
                cancel.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 0.3f));

                tr = new TableRow(ctx);
                tr.setWeightSum(2);
                tr.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

                prod_tbl.addView(tr);
                tr.addView(spin, 0);
                tr.addView(cancel,1);
 */
