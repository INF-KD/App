package com.kd.ronakayurvedic;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Welcome extends AppCompatActivity {

    Button back, add, profile;
    Context ctx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_appbar);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ctx = this;
        back = findViewById(R.id.back);
        add = findViewById(R.id.btn_add);
        profile = findViewById(R.id.btn_profile);

        events();
    }

    private void events(){

//  Back button onclick event
        devs.btn_back(this, back);

// Add button onclick event
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent go_to_add = new Intent(getApplicationContext(), Add.class);
                startActivity(go_to_add);
            }
        });

// go to profile event
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                devs.call_intent(ctx, getApplicationContext(), Profile.class);
            }
        });

    }
}
