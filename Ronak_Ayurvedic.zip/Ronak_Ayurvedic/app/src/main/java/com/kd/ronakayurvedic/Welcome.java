package com.kd.ronakayurvedic;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Welcome extends AppCompatActivity {

    Button back, add, purchase, sell, profile;
    Context ctx;
    //DBManager dbM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_appbar);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ctx = this;
        //dbM = DBManager.getInstance(ctx);
        back = findViewById(R.id.back);
        add = findViewById(R.id.btn_add);
        purchase = findViewById(R.id.btn_purchase);
        sell = findViewById(R.id.btn_sell);
        profile = findViewById(R.id.btn_profile);

        //dbM.open();
        events();
    }

    private View.OnClickListener goIntenet = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            if(v instanceof Button) {
                if (v == sell)
                    devs.call_intent(ctx, getApplicationContext(), Sell.class);
                else if (v == purchase)
                    devs.call_intent(ctx, getApplicationContext(), Purchase.class);
                else if (v == add)
                    devs.call_intent(ctx, getApplicationContext(), Add.class);
                else if (v == profile)
                    devs.call_intent(ctx, getApplicationContext(), Profile.class);
            }
        }
    };

    private void events(){

//  Back button onclick event
        devs.btn_back(this, back);

// Add button onclick event
        profile.setOnClickListener(goIntenet);
        sell.setOnClickListener(goIntenet);
        purchase.setOnClickListener(goIntenet);
        add.setOnClickListener(goIntenet);

        //dbM.getCompanyList();
        //dbM.close();
    }
}
