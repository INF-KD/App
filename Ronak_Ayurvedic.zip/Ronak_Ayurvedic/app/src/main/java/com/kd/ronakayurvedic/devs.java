package com.kd.ronakayurvedic;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;

import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class devs {

//    Back button event
    public static void btn_back(final Context act, Button btn){
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((Activity)act).finish();
            }
        });
    }

//    call new intent method
    public static void call_intent(Context this_ctx, final Context app_ctx, Class<?> cls){
        Intent i = new Intent(app_ctx, cls);
        this_ctx.startActivity(i);
    }

//    add header row to table layout
    public static void addHeaderFields(Context ctx, TableLayout tbl, String[] fields){
        TableLayout.LayoutParams params = new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.MATCH_PARENT);
        TableRow head = new TableRow(ctx);
        head.setLayoutParams(params);
        for(String field : fields){
            TextView tv = (TextView) View.inflate(ctx, R.layout.header_textview, null);
            tv.setText(field);
            head.addView(tv);
        }
        tbl.addView(head);
    }

//    add data to TableRow
    public static TableRow fillRow(Context ctx, ArrayList<String> data, int i, ArrayList percentage){
        TableLayout.LayoutParams params = new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.MATCH_PARENT);
        TableRow tr = new TableRow(ctx);
        tr.setLayoutParams(params);
        TextView no = (TextView) View.inflate(ctx, R.layout.data_textview, null);
        no.setText(String.valueOf(i+1));
        tr.addView(no);
        int ind = 0;
        for(String item : data){
            TextView tv = (TextView) View.inflate(ctx, R.layout.data_textview, null);
            if(percentage.contains(ind)){
                item = item + "%";
            }
            tv.setText(item);
            tr.addView(tv);
            ind++;
        }
        return tr;
    }

// create ImageView
    public static ImageView getImage(Context ctx, View.OnClickListener on_clk, String lbl){
        int id = ctx.getResources().getIdentifier(lbl, "layout", ctx.getPackageName());
        ImageView img = (ImageView) View.inflate(ctx, id, null);
        img.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT));
        img.setOnClickListener(on_clk);
        img.setTag(lbl);
        return img;
    }

//    Helper functions (Developer Defined)

    public static ArrayList getFieldsArray(int[] field){
        ArrayList arr = new ArrayList();
        for(int i : field){
            arr.add(i);
        }
        return arr;
    }
    public static void empty(EditText ... ebs){
        for (EditText et : ebs){
            et.setText("");
        }
    }
    public static void empty(TextView ... tvs){
        for(TextView tv : tvs){
            tv.setText("");
        }
    }
    public static ArrayList<String> append(EditText ... ets){
        ArrayList<String> list = new ArrayList<>();
        for(EditText et : ets) {
            list.add(Integer.valueOf(et.getTag().toString()),  getData(et));
        }
        return list;
    }

    public static String getData(EditText txt){
        String data = txt.getText().toString();
        return data;
    }
    public static String getData(Spinner spin){
        String data = spin.getSelectedItem().toString();
        return data;
    }

    public static void setData(EditText txt, String data){
        txt.setText(data);
    }

    public static boolean chkNull(EditText ... ets){
        for(EditText et : ets){
            String data = getData(et);
            if(data.isEmpty() || data.equals("") || data.equals(" ")){
                return false;
            }
        }
        return true;
    }

    public static void Toasty(Context ctx, String msg){
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
    }

//    End helper functions

//    Show date picker code

    final static Calendar myCalendar = Calendar.getInstance();

    public static void setDatePicker(final Context ctx, final EditText et){

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel(et);
            }

        };

        et.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(ctx, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

    }

    private static void updateLabel(EditText et) {
        String myFormat = "yyyy-MM-dd"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        et.setText(sdf.format(myCalendar.getTime()));
    }

//    End date picker code

    public static void getPDF(final Context ctx, final ArrayList<ArrayList<String>> datas, final int total, final String customer, final String c_addr, final String date, final String bill_no){
        String mUrl= "http://online-billing-app.000webhostapp.com/insert.php";
        InputStreamVolleyRequest request = new InputStreamVolleyRequest(Request.Method.POST, mUrl,
                new Response.Listener<byte[]>() {
                    @Override
                    public void onResponse(byte[] response) {
                        // TODO handle the response
                        try {
                            if (response!=null) {
                                Log.d("......response.......", new String(response));
                                FileOutputStream outputStream;
                                String name="Bill.pdf";
                                outputStream = ctx.openFileOutput(name, Context.MODE_PRIVATE);
                                outputStream.write(response);
                                outputStream.close();
                                Toasty(ctx, "Download Completed");
                                datas.clear();

                            }
                        } catch (Exception e) {
                            // TODO Auto-generated catch block
                            Log.d("KEY_ERROR", "UNABLE TO DOWNLOAD FILE");
                            e.printStackTrace();
                        }
                    }
                } ,new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                // TODO handle the error
                error.printStackTrace();
            }
        }, null){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> MyData = new HashMap<>();
                ArrayList<ArrayList<String>> hola = new ArrayList<>();
                int i=1;
                for(ArrayList<String> data : datas){
                    ArrayList<String> one = new ArrayList<>();
                    one.add(String.valueOf(i));
                    one.add(data.get(3));
                    one.add(data.get(4));
                    one.add(data.get(6));
                    one.add(data.get(5));
                    one.add(data.get(7)+"%");
                    one.add(data.get(8));
                    hola.add(one);
                    i++;
                }
                JSONArray js = new JSONArray(hola);
                Log.d("......Array.....", js.toString());
                MyData.put("datas", js.toString());
                MyData.put("bill_no", bill_no);
                MyData.put("c_nm", customer);
                MyData.put("c_addr", c_addr);
                String formatted = "";
                try {
                    Date dt = new SimpleDateFormat("yyyy-MM-dd").parse(date);
                    DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
                    formatted = df.format(dt);
                } catch (Exception ex) {
                    Log.d("Date Conversion error", ex.getMessage());
                }
                MyData.put("date", formatted.isEmpty() ? date : formatted);
                MyData.put("total", String.valueOf(total));
                return MyData;
            }
        };
        request.setShouldCache(false);
        RequestQueue mRequestQueue = Volley.newRequestQueue(ctx.getApplicationContext(), new HurlStack());
        mRequestQueue.getCache().clear();
        mRequestQueue.add(request);
    }
}

