package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Add extends AppCompatActivity {

    Button back, add_c, add_p, profile;
    Context ctx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_appbar);

        Toolbar toolbar = findViewById(R.id.add_toolbar);
        setSupportActionBar(toolbar);

        ctx = this;
        back = findViewById(R.id.back);
        add_c = findViewById(R.id.btn_add_cmp);
        add_p = findViewById(R.id.btn_add_prod);
        profile = findViewById(R.id.btn_profile);
        events();
    }

    private void events() {

//  Back button onclick event
        devs.btn_back(ctx, back);

//  btn event for add company
        add_c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                devs.call_intent(ctx, getApplicationContext(), add_company.class);
            }
        });

//  btn event for add product
        add_p.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                devs.call_intent(ctx, getApplicationContext(), add_product.class);
            }
        });

// go to profile event
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                devs.call_intent(ctx, getApplicationContext(), Profile.class);
            }
        });

    }

}
