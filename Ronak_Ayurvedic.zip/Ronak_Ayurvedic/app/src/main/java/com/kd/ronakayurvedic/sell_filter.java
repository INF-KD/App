package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;

public class sell_filter extends AppCompatActivity {

    Context ctx;
    DBManager dbM;
    Button back;
    EditText from_date, to_date;
    AutoCompleteTextView txt_sellProduct;
    TableLayout data_tbl;
    TableRow tr;
    String[] fields, data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sell_filter);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

//      Initialization
        ctx = this;
        dbM = DBManager.getInstance(ctx);
        back = findViewById(R.id.back);
        from_date = findViewById(R.id.txt_sf_from_date);
        to_date = findViewById(R.id.txt_sf_to_date);
        txt_sellProduct = findViewById(R.id.txt_sf_product);

//      Add header to table
        data_tbl = findViewById(R.id.sell_f_tbl);
        fields = new String[]{"No.", "Product", "Company", "Bench no.", "Date", "Qty", "MRP", "Total"};
        devs.addHeaderFields(ctx, data_tbl, fields);

        events();
    }

    private void events() {

//      Back button onclick event
        devs.btn_back(this, back);

//      Add datepicker to textbox
        devs.setDatePicker(ctx, from_date);
        devs.setDatePicker(ctx, to_date);

//      Add autocomplete hints to textbox
        ArrayAdapter<String> forAuto = new ArrayAdapter<String>(ctx, R.layout.support_simple_spinner_dropdown_item, dbM.getSellProductList());
        forAuto.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        txt_sellProduct.setAdapter(forAuto);

    }
}
