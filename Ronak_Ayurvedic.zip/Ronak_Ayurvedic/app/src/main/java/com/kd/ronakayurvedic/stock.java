package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;

public class stock extends AppCompatActivity {

    Context ctx;
    Button back;
    TableLayout data_tbl;
    TableRow tr;
    String[] fields;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stock);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ctx = this;
        back = findViewById(R.id.back);
        data_tbl = findViewById(R.id.stock_tbl);


        fields = new String[]{"No.", "Product", "Company", "Batch no", "Purchase", "Sell", "Stock"};
        devs.addHeaderFields(ctx, data_tbl, fields);

        events();
    }

    private void events() {
//  Back button onclick event
        devs.btn_back(this, back);
    }
}
