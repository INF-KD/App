package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;

import java.util.ArrayList;

public class add_company extends AppCompatActivity {

    Button back, save, cancel, profile;
    EditText cmp_nm, cmp_owner, cmp_loc, cmp_contact;
    TableLayout cmp_tbl;
    TableRow tr;
    ArrayList<String> cmp_details;
    ArrayAdapter<String> adt;
    Spinner spin;
    Context ctx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_company_appbar);
        ctx = this;

        back = findViewById(R.id.back);
        save = findViewById(R.id.btn_save);
        profile = findViewById(R.id.btn_profile);

        cmp_nm = findViewById(R.id.txt_cmp_nm);
        cmp_owner = findViewById(R.id.txt_owner);
        cmp_loc = findViewById(R.id.txt_loc);
        cmp_contact = findViewById(R.id.txt_mob);

        cmp_tbl = findViewById(R.id.cmp_tbl);

        events();
    }

    private void events(){
//  Back button onclick event
        devs.btn_back(this, back);

// go to profile event
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                devs.call_intent(ctx, getApplicationContext(), Profile.class);
            }
        });

// save event
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nm = cmp_nm.getText().toString();
                String owner = cmp_owner.getText().toString();
                String loc = cmp_loc.getText().toString();
                String no = cmp_contact.getText().toString();
                cmp_details = new ArrayList<String>();
                cmp_details.add(nm);
                cmp_details.add(owner);
                cmp_details.add(loc);
                cmp_details.add(no);

                adt =new ArrayAdapter<String>(ctx, R.layout.custom_spin_view, cmp_details);
                adt.setDropDownViewResource(R.layout.custom_spin_view);
                adt.notifyDataSetChanged();

                spin = new Spinner(ctx, Spinner.MODE_DIALOG);
                spin.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1.7f));
                spin.setAdapter(adt);
                spin.setSelected(true);

                cancel = new Button(ctx);
                cancel.setBackgroundResource(R.drawable.del_icon);
                cancel.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 0.3f));

                tr = new TableRow(ctx);
                tr.setWeightSum(2);
                tr.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

                cmp_tbl.addView(tr);
                tr.addView(spin, 0);
                tr.addView(cancel,1);

            }
        });
    }
}
