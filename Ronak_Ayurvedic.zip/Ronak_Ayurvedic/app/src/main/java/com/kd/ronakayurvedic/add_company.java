package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

import java.util.ArrayList;

public class add_company extends AppCompatActivity {

    Button back, save, cancel, profile;
    DBManager dbM;
    EditText cmp_nm, cmp_owner, cmp_loc, cmp_contact;
    TableLayout cmp_tbl;
    TableRow tr;
    ArrayList<String> cmp_data;
    ArrayAdapter<String> adt;
    Spinner spin;
    Context ctx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_company_appbar);

        ctx = this;
        dbM = DBManager.getInstance(ctx);
        back = findViewById(R.id.back);
        save = findViewById(R.id.btn_save);
        profile = findViewById(R.id.btn_profile);

        cmp_nm = findViewById(R.id.txt_cmp_nm);
        cmp_owner = findViewById(R.id.txt_owner);
        cmp_loc = findViewById(R.id.txt_loc);
        cmp_contact = findViewById(R.id.txt_mob);

        cmp_tbl = findViewById(R.id.cmp_tbl);

        dbM.open();
        events();
        updateTable();
    }

    private View.OnClickListener clk_listener = new View.OnClickListener() {
        public void onClick(View v) {
            if (v instanceof Button) {
                if (v == save) {
                    cmp_data = new ArrayList<String>();
                    String cmp = cmp_nm.getText().toString();
                    String own = cmp_owner.getText().toString();
                    String loc = cmp_loc.getText().toString();
                    String ph = cmp_contact.getText().toString();
                    if(!cmp.isEmpty() && !own.isEmpty() && !loc.isEmpty() && !ph.isEmpty()) {
                        cmp_data.add(0, cmp);
                        cmp_data.add(1, own);
                        cmp_data.add(2, loc);
                        cmp_data.add(3, ph);
                        if (dbM.ins_company(cmp_data)) {
                            cmp_data = null;
                            Toasty("Inserted");
                            devs.empty(cmp_nm, cmp_owner, cmp_loc);
                            devs.setData(cmp_contact, "+91-");
                            updateTable();
                        }
                    }else{
                        Toasty("Any field is blank,\nNot inserted successfully");
                    }
                }else if(v == profile){
                    devs.call_intent(ctx, getApplicationContext(), Profile.class);
                }else if(v.getTag() != null){
                    String index = v.getTag().toString();
                    if(dbM.del_company(index)) {
                        updateTable();
                    }else{
                        Toasty("Not deleted");
                    }
                }
            }
        }
    };

    private void events(){
//  Back button onclick event
        devs.btn_back(this, back);

        profile.setOnClickListener(clk_listener);
        save.setOnClickListener(clk_listener);
    }

    private void updateTable(){
        cmp_tbl.removeAllViews();
        ArrayList<ArrayList<String>> list = dbM.getCompanies();

        for(ArrayList<String> one : list) {
            ArrayList<String> cmp_details = new ArrayList<String>();
            cmp_details.add(one.get(0));
            cmp_details.add(one.get(1));
            cmp_details.add(one.get(2));
            cmp_details.add(one.get(3));

            adt = new ArrayAdapter<>(ctx, R.layout.custom_spin_view, cmp_details);
            adt.setDropDownViewResource(R.layout.custom_spin_view);

            spin = new Spinner(ctx, Spinner.MODE_DIALOG);
            spin.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1.7f));
            spin.setAdapter(adt);
            spin.setSelected(true);

            cancel = new Button(ctx);
            cancel.setBackgroundResource(R.drawable.delete);
            cancel.setTag(one.get(4));
            cancel.setOnClickListener(clk_listener);
            cancel.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 0.3f));

            tr = new TableRow(ctx);
            tr.setWeightSum(2);
            tr.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

            cmp_tbl.addView(tr);
            tr.addView(spin, 0);
            tr.addView(cancel, 1);
        }
    }

    private void Toasty(String msg){
        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show();
    }
}
