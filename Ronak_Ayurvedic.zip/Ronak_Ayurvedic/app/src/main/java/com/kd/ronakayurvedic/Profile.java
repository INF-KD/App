package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Profile extends AppCompatActivity {

    Button back, profile;
    Context ctx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);

        Toolbar toolbar = findViewById(R.id.add_toolbar);
        setSupportActionBar(toolbar);

        ctx = this;
        back = findViewById(R.id.back);
        profile = findViewById(R.id.btn_profile);
        events();
    }

    private void events() {

//  Back button onclick event
        devs.btn_back(this, back);

// go to profile event
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                devs.call_intent(ctx, getApplicationContext(), Profile.class);
            }
        });

    }

}

