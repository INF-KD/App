package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Profile extends AppCompatActivity {

    Button back, sell_f, purchase_f, customer_bills, stock;
    Context ctx;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);

        Toolbar toolbar = findViewById(R.id.add_toolbar);
        setSupportActionBar(toolbar);

        ctx = this;
        back = findViewById(R.id.back);
        sell_f = findViewById(R.id.btn_sell_filter);
        purchase_f = findViewById(R.id.btn_purchase_filter);
        customer_bills = findViewById(R.id.btn_customer_filter);
        stock = findViewById(R.id.btn_stock_filter);
        events();
    }

    private View.OnClickListener goForIntent = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            if(v == sell_f){
                devs.call_intent(ctx, getApplicationContext(), sell_filter.class);
            }else if(v == purchase_f){
                devs.call_intent(ctx, getApplicationContext(), purchase_filter.class);
            }else if(v == customer_bills){
                devs.call_intent(ctx, getApplicationContext(), customer_bills.class);
            }else if(v == stock){
                devs.call_intent(ctx, getApplicationContext(), stock.class);
            }

        }
    };

    private void events() {

//  Back button onclick event
        devs.btn_back(this, back);
        sell_f.setOnClickListener(goForIntent);
        purchase_f.setOnClickListener(goForIntent);
        customer_bills.setOnClickListener(goForIntent);
        stock.setOnClickListener(goForIntent);
    }

}

