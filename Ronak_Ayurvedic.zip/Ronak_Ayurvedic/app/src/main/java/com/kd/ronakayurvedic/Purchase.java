package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import de.codecrafters.tableview.TableView;
import de.codecrafters.tableview.toolkit.SimpleTableHeaderAdapter;

public class Purchase extends AppCompatActivity {

    Button back;
    Context ctx;
    EditText txt_date;
    TableLayout data_tbl;
    String[] purchase_header;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.purchase);

        Toolbar toolbar = findViewById(R.id.add_toolbar);
        setSupportActionBar(toolbar);

        ctx = this;

        data_tbl = findViewById(R.id.purchase_tbl);
        TableRow head_tr = findViewById(R.id.head_row);

        purchase_header = new String[]{"No.", "Bill no.", "Date", "Company", "Product", "Bench no.", "Qty", "Net rate", "MRP", "SGST%", "CGST%", "Discount", "Total", "Edit", "Delete"};

        for(String item : purchase_header){
            TextView tv = (TextView) View.inflate(ctx, R.layout.header_textview, null);
            tv.setText(item);
            if(item.equals("Edit") || item.equals("Delete")){
                tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
            }
            head_tr.addView(tv);
        }

        back = findViewById(R.id.back);
        txt_date = findViewById(R.id.txt_date);
        events();
    }

    private void events() {

//  Back button onclick event
        devs.btn_back(this, back);
        devs.setDatePicker(ctx, txt_date);
    }

}

/*
        TableRow tr = new TableRow(this);
        TableLayout.LayoutParams layoutP = new TableLayout.LayoutParams(TableLayout.LayoutParams.WRAP_CONTENT, TableLayout.LayoutParams.WRAP_CONTENT);
        tr.setLayoutParams(layoutP);
        String[] datas = new String[]{"1", "Hola1", "12/12/2019", "Herbal Care", "Chyvanprash", "BA03", "2", "20", "40", "3", "3", "2", "50"};
        for(String item : datas){
            TextView tv = (TextView) View.inflate(ctx, R.layout.data_textview, null);
            tv.setText(item);
            tr.addView(tv);
        }
        Button btn_del = new Button(this);
        btn_del.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 0.3f));
        btn_del.setBackground(ContextCompat.getDrawable(ctx, R.drawable.delete));
        Button btn_edit = new Button(this);
        btn_edit.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 0.3f));
        btn_edit.setBackground(ContextCompat.getDrawable(ctx, R.drawable.edit));
        tr.addView(btn_edit);
        tr.addView(btn_del);
        data_tbl.addView(tr);
*/
