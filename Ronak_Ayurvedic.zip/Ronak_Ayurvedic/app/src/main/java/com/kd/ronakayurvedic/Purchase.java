package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;

public class Purchase extends AppCompatActivity {

    Context ctx;
    DBManager dbM;
    Button back, profile, add, save;
    EditText txt_bill, txt_date, txt_net_r, txt_qty, txt_mrp, txt_sgst, txt_cgst, txt_disc, txt_amount;
    AutoCompleteTextView txt_cmp, txt_prod, txt_batch;
    TextView lbl_ttl, lbl_disc, lbl_gst, lbl_f_ttl;
    TableLayout data_tbl;
    TableRow tr;
    String[] purchase_header;
    ArrayList<ArrayList<String>> purchase_data;
    ArrayAdapter<String> cmp_adp, prod_adp, batch_adp;
    float total, disc, gst;
    int f_ttl, change_index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.purchase);

        Toolbar toolbar = findViewById(R.id.add_toolbar);
        setSupportActionBar(toolbar);

        ctx = this;
        dbM = DBManager.getInstance(ctx);

//  EditText initialization
        txt_bill = findViewById(R.id.txt_bill_no);
        txt_date = findViewById(R.id.txt_date);
        txt_net_r = findViewById(R.id.txt_net_rate);
        txt_qty = findViewById(R.id.txt_quantity);
        txt_mrp = findViewById(R.id.txt_mrp);
        txt_sgst = findViewById(R.id.txt_sgst);
        txt_cgst = findViewById(R.id.txt_cgst);
        txt_disc = findViewById(R.id.txt_discount);
        txt_amount = findViewById(R.id.txt_total);
//  AutoCompleteTextView
        txt_cmp = findViewById(R.id.txt_cmp);
        txt_prod = findViewById(R.id.txt_product);
        txt_batch = findViewById(R.id.txt_batch_no);
//  Button
        back = findViewById(R.id.back);
        profile = findViewById(R.id.btn_profile);
        add = findViewById(R.id.btn_add_to_current);
        save = findViewById(R.id.btn_save_purchase);
// TextView
        lbl_ttl = findViewById(R.id.purchase_ttl);
        lbl_disc = findViewById(R.id.purchase_discount);
        lbl_gst = findViewById(R.id.purchase_gst);
        lbl_f_ttl = findViewById(R.id.purchase_f_ttl);

        data_tbl = findViewById(R.id.purchase_tbl);

        purchase_data = new ArrayList<>();
        dbM.open();
        events();
    }

    private void events() {

//  Back button onclick event
        devs.btn_back(this, back);
        devs.setDatePicker(ctx, txt_date);

//  Button listener
        profile.setOnClickListener(view_listener);
        add.setOnClickListener(view_listener);
        save.setOnClickListener(view_listener);

//  TextChange listener
        txt_net_r.addTextChangedListener(text_listener);
        txt_qty.addTextChangedListener(text_listener);
        txt_sgst.addTextChangedListener(text_listener);
        txt_cgst.addTextChangedListener(text_listener);
        txt_disc.addTextChangedListener(text_listener);


//  Set Adapters to EditText
        ArrayList<String> cmpList = dbM.getCompanyList(true);
        cmpList.remove(0);
        cmp_adp = new ArrayAdapter<String>(ctx, R.layout.support_simple_spinner_dropdown_item, cmpList);
        cmp_adp.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        txt_cmp.setAdapter(cmp_adp);
        txt_cmp.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String cmp = String.valueOf(parent.getItemAtPosition(position));
                setAdapterToProduct(cmp);
            }
        });

    }

    private void addHeader(){
        try {
            View v = data_tbl.getChildAt(0);
            if (v == null) {
                purchase_header = new String[]{"No.", "Bill no.", "Date", "Company", "Product", "Bench no.", "Net rate", "Qty", "MRP", "SGST%", "CGST%", "Discount", "Total", "Edit", "Delete"};
                devs.addHeaderFields(ctx, data_tbl, purchase_header);
            }
        } catch (Exception ex){
            devs.Toasty(ctx, ex.getMessage());
        }
    }

    //  set ArrayAdapters on correspondence selections
    private void setAdapterToProduct(String cmpnm){
        prod_adp = new ArrayAdapter<String>(ctx, R.layout.support_simple_spinner_dropdown_item, dbM.getProductList(true, cmpnm));
        prod_adp.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        txt_prod.setAdapter(prod_adp);
        txt_prod.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String prod = String.valueOf(parent.getItemAtPosition(position));
                setAdapterToBatch(prod);
            }
        });
    }

    private void setAdapterToBatch(String pnm){
        batch_adp = new ArrayAdapter<>(ctx, R.layout.custom_spin_view, dbM.getBatchNo(pnm));
        batch_adp.setDropDownViewResource(R.layout.custom_spin_view);
        txt_batch.setAdapter(batch_adp);
    }
//  end of ArrayAdapters

//  Discount, Total, GST & grand total Operations
    private float getTotal(){
        String net_r = txt_net_r.getText().toString();
        String qty = txt_qty.getText().toString();
        float TOTAL = 0;
        if (!net_r.isEmpty() && !qty.isEmpty()) {
            float NET_R = Float.valueOf(net_r);
            float QTY = Float.valueOf(qty);
            TOTAL = NET_R * QTY;
        }
        return TOTAL;
    }
    private float getDisc(){
        String disc = txt_disc.getText().toString();
        disc = disc.equals("") ? "0" : disc;
        float DISC = Float.valueOf(disc.replaceAll("[^0-9]", ""));
        return ((getTotal() * DISC) / 100);
    }
    private float getSGST(){
        String sgst = txt_sgst.getText().toString();
        sgst = sgst.equals("") ? "0" : sgst.replaceAll("[^0-9]", "");
        float SGST = ((getTotal() - getDisc()) * Float.valueOf(sgst)) / 100;
        return SGST;
    }
    private float getCGST(){
        String cgst = txt_cgst.getText().toString();
        cgst = cgst.equals("") ? "0" : cgst.replaceAll("[^0-9]", "");
        float CGST = ((getTotal() - getDisc()) * Float.valueOf(cgst)) / 100;
        return CGST;
    }
    private void updateTotal(){
        lbl_ttl.setText(String.valueOf(total));
        lbl_disc.setText(String.valueOf(disc));
        lbl_gst.setText(String.valueOf(gst));
        lbl_f_ttl.setText(String.valueOf(f_ttl));
    }


//  Listener classes
    private View.OnClickListener view_listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
        if (v instanceof Button) {
            if (v == add) {
                boolean flag = devs.chkNull(txt_bill, txt_date, txt_cmp, txt_prod, txt_batch, txt_net_r, txt_qty, txt_mrp, txt_sgst, txt_cgst, txt_disc, txt_amount);
                if (flag) {
                    // here ! is to prevent else part
                    if (!(dbM.getCompanyList(true).contains(devs.getData(txt_cmp)) && dbM.getProductList(true, devs.getData(txt_cmp)).contains(devs.getData(txt_prod)))) {
                        devs.Toasty(ctx, "Company or Product Mis-Matches");
                        flag = !flag;
                    }
                }
                if (!add.getTag().equals("Edit") && flag) {
                    addHeader();

                    ArrayList<String> datas = devs.append(txt_bill, txt_date, txt_cmp, txt_prod, txt_batch, txt_net_r, txt_qty, txt_mrp, txt_sgst, txt_cgst, txt_disc, txt_amount);
                    int index = purchase_data.size();
                    purchase_data.add(index, datas);

                    tr = devs.fillRow(ctx, datas, index, devs.getFieldsArray(new int[]{8, 9, 10}));
                    tr.addView(devs.getImage(ctx, view_listener, "edit_icon"));
                    tr.addView(devs.getImage(ctx, view_listener, "delete_icon"));
                    data_tbl.addView(tr);

                    total += getTotal();
                    disc += getDisc();
                    gst += getSGST() + getCGST();
                    f_ttl = Math.round((total - disc) + gst);

                    updateTotal();
                    devs.empty(txt_cmp, txt_prod, txt_batch, txt_net_r, txt_qty, txt_mrp, txt_sgst, txt_cgst, txt_disc, txt_amount);
                } else if (add.getTag().equals("Edit") && flag) {
                    ArrayList<String> one_data = purchase_data.get(change_index);
                    float net_r = Float.valueOf(one_data.get(5));
                    float qty = Float.valueOf(one_data.get(6));
                    float sgst = Float.valueOf(one_data.get(8));
                    float cgst = Float.valueOf(one_data.get(9));
                    float dis = Float.valueOf(one_data.get(10));

                    total -= net_r * qty;
                    disc -= (net_r * qty * dis) / 100;
                    gst -= ((net_r * qty - ((net_r * qty * dis)/ 100)) * (sgst + cgst))/100;
                    f_ttl = Math.round((total - disc) + gst);

                    ArrayList<String> datas = devs.append(txt_bill, txt_date, txt_cmp, txt_prod, txt_batch, txt_net_r, txt_qty, txt_mrp, txt_sgst, txt_cgst, txt_disc, txt_amount);
                    purchase_data.add(change_index, datas);

                    tr = devs.fillRow(ctx, datas, change_index, devs.getFieldsArray(new int[]{8, 9, 10}));
                    tr.addView(devs.getImage(ctx, view_listener, "edit_icon"));
                    tr.addView(devs.getImage(ctx, view_listener, "delete_icon"));
                    data_tbl.removeView(data_tbl.getChildAt(change_index+1));
                    data_tbl.addView(tr, change_index+1);

                    total += getTotal();
                    disc += getDisc();
                    gst += getSGST() + getCGST();
                    f_ttl = Math.round((total - disc) + gst);

                    add.setTag("Add");
                    updateTotal();
                    devs.empty(txt_cmp, txt_prod, txt_batch, txt_net_r, txt_qty, txt_mrp, txt_sgst, txt_cgst, txt_disc, txt_amount);
                } else {
                    devs.Toasty(ctx, "Some data is empty");
                }
            } else if (v == save) {
                if(purchase_data.size() != 0){
                    if(dbM.do_purchase(purchase_data)){
                        purchase_data.clear();
                        data_tbl.removeAllViews();
                        total = 0.0f; disc = 0.0f; gst = 0.0f; f_ttl = 0;
                        updateTotal();
                        devs.Toasty(ctx, "Inserted successfully");
                    } else {
                        devs.Toasty(ctx, "Some problem occurs,\nNot inserted successfully");
                    }
                } else {
                    devs.Toasty(ctx, "Please first insert the data");
                }
            } else if (v == profile) {
                devs.call_intent(ctx, getApplicationContext(), Profile.class);
            }
        } else if (v instanceof ImageView){
            if(v.getTag().equals("delete_icon")){
                TableRow data_row = (TableRow) v.getParent();
                TextView tv = (TextView) data_row.getChildAt(0);

                int index = Integer.valueOf(tv.getText().toString()) - 1;
                ArrayList<String> one_data = purchase_data.get(index);
                float net_r = Float.valueOf(one_data.get(5));
                float qty = Float.valueOf(one_data.get(6));
                float sgst = Float.valueOf(one_data.get(8));
                float cgst = Float.valueOf(one_data.get(9));
                float dis = Float.valueOf(one_data.get(10));

                total -= net_r * qty;
                disc -= (net_r * qty * dis) / 100;
                gst -= ((net_r * qty - ((net_r * qty * dis)/ 100)) * (sgst + cgst))/100;
                f_ttl = Math.round((total - disc) + gst);

                updateTotal();
                data_tbl.removeView(data_row);
                purchase_data.remove(index);
            } else if (v.getTag().equals("edit_icon")){
                TableRow data_row = (TableRow) v.getParent();
                TextView tv = (TextView) data_row.getChildAt(0);
                int index = Integer.valueOf(tv.getText().toString()) - 1;

                ArrayList<String> one_data = purchase_data.get(index);
                devs.setData(txt_bill, one_data.get(0));
                devs.setData(txt_date, one_data.get(1));
                devs.setData(txt_cmp, one_data.get(2));
                devs.setData(txt_prod, one_data.get(3));
                devs.setData(txt_batch, one_data.get(4));
                devs.setData(txt_net_r, one_data.get(5));
                devs.setData(txt_qty, one_data.get(6));
                devs.setData(txt_mrp, one_data.get(7));
                devs.setData(txt_sgst, one_data.get(8));
                devs.setData(txt_cgst, one_data.get(9));
                devs.setData(txt_disc, one_data.get(10));
                devs.setData(txt_amount, one_data.get(11));

                add.setTag("Edit");
                change_index = index;
            }
        }
        }
    };

    TextWatcher text_listener = new TextWatcher() {
        @Override
        public void afterTextChanged(Editable s) {
            try {
                float TOTAL = getTotal();
                float DISC = getDisc();
                float GST = getSGST() + getCGST();
                if (TOTAL != 0) {
                    float AMOUNT = (TOTAL - DISC) + GST;
                    txt_amount.setText(String.valueOf(AMOUNT));
                }
            }catch (Exception ex){
                devs.Toasty(ctx, "Please inset a valid data\n" + ex.getMessage());
            }
        }

        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
    };

}

/*
        // Delete on click code
        ImageView del_img = (ImageView) View.inflate(ctx, R.layout.delete_icon, null);
        del_img.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT));
        del_img.setOnClickListener(forProcess);
        del_img.setTag("DEL");
        tr.addView(del_img);
        private View.OnClickListener forProcess = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v instanceof ImageView){
                    if(v.getTag().equals("DEL")){
                        TableRow get_tr = (TableRow)v.getParent();
                        String str = ((TextView)get_tr.getChildAt(0)).getText().toString();
                        Toast.makeText(ctx, str, Toast.LENGTH_LONG).show();
                        data_tbl.removeView(get_tr);
                    }
                }
            }
        };


        TableRow tr = new TableRow(this);
        TableLayout.LayoutParams layoutP = new TableLayout.LayoutParams(TableLayout.LayoutParams.WRAP_CONTENT, TableLayout.LayoutParams.WRAP_CONTENT);
        tr.setLayoutParams(layoutP);
        String[] datas = new String[]{"1", "Hola1", "12/12/2019", "Herbal Care", "Chyvanprash", "BA03", "2", "20", "40", "3", "3", "2", "50"};
        for(String item : datas){
            TextView tv = (TextView) View.inflate(ctx, R.layout.data_textview, null);
            tv.setText(item);
            tr.addView(tv);
        }
        Button btn_del = new Button(this);
        btn_del.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 0.3f));
        btn_del.setBackground(ContextCompat.getDrawable(ctx, R.drawable.delete));
        Button btn_edit = new Button(this);
        btn_edit.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 0.3f));
        btn_edit.setBackground(ContextCompat.getDrawable(ctx, R.drawable.edit));
        tr.addView(btn_edit);
        tr.addView(btn_del);
        data_tbl.addView(tr);
*/
