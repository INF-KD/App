package com.kd.ronakayurvedic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;

public class customer_bills extends AppCompatActivity {

    Context ctx;
    DBManager dbM;
    Button back, view;
    AutoCompleteTextView txt_c_nm;
    TableLayout data_tbl;
    TableRow tr;
    String[] fields;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_bills);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ctx = this;
        dbM = DBManager.getInstance(ctx);
        back = findViewById(R.id.back);
        txt_c_nm = findViewById(R.id.txt_prod_nm);
        view = findViewById(R.id.btn_view);
        data_tbl = findViewById(R.id.customer_tbl);

        events();
    }

    private void events() {

//  Back button onclick event
        devs.btn_back(this, back);

//      Add autocomplete hints to textbox
        ArrayAdapter<String> forAuto = new ArrayAdapter<String>(ctx, R.layout.support_simple_spinner_dropdown_item, dbM.getCustomerList());
        forAuto.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        txt_c_nm.setAdapter(forAuto);

//      View event
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fields = new String[]{"No.", "Customer Name", "Date", "View"};
                devs.addHeaderFields(ctx, data_tbl, fields);
            }
        });

    }
}
